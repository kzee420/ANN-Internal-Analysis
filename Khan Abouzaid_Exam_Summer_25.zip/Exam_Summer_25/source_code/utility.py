import matplotlib.pyplot as plt

colors = ["#eaeaf2", "#721817", "#2b4162", "#fa9f42"]

def prepare_plot():
    ax = plt.axes()
    ax.set_facecolor(colors[0])   

def finish_plot( filename=None, ylim=None ):
    legend = plt.legend(  )
    legend.get_frame().set_alpha( 0.0 )  
    if not filename is None:
        plt.savefig(filename, dpi=300, bbox_inches='tight')
    plt.show()
    
def plot_model_fit( X, Y, X_trend, Y_trend, ylim=None, filename=None):
    prepare_plot()    
    plt.plot(X_trend, Y_trend, color=colors[2], linewidth=3, label="Fitted Model")
    plt.scatter(X, Y, color=colors[1], alpha=0.75, label="Training Data")
    finish_plot( filename=filename, ylim=ylim )